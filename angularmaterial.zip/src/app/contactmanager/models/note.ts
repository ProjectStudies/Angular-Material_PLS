export class Note {
    id: number;
    title: string;
    date: Date;
}
